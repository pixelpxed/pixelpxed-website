// General variables
var versionnumber = "2.3.0"
var copyrightyear = "2022"

// Translation Variables
var var_day_primary = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
var var_month_primary = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

var var_day_secondary = ["S-Sunday", "S-Monday", "S-Tuesday", "S-Wednesday", "S-Thursday", "S-Friday", "S-Saturday"]
var var_month_secondary = ["S-January", "S-February", "S-March", "S-April", "S-May", "S-June", "S-July", "S-August", "S-September", "S-October", "S-November", "S-December"]

var timetable_title_primary = "Timetable"
var timetable_title_secondary = "Secondary Timetable"

var timetable_description_primary = "Left Click - Video Call<br>Right Click - Classroom"
var timetable_description_secondary = "Secondary<br>Description" // <br> - For a new line.

// Switch for Japanese and Chinese class / Switch for changing between primary and secondary language (By default both false)
var japanesechinese = false
var secondarylanguage = true

// Time to be displayed in Timetable
const time = ["08:00 - 08:40", "08:40 - 09:20", "09:20 - 10:00", "10:20 - 11:00", "11:00 - 11:40", "12:00 - 12:40", "12:40 - 13:20", "13:40 - 14:20", "14:20 - 15:00", "15:20 - 16:00", "16:00 - 16:40"]

// Class to be displayed in Timetable, each line represents each day.
// Automatic operations (All of the below is case-sensitive):
// "Lunch"   - Will set the grid as a lunch grid automaticly
// "Break"   - Will set the grid as a break grid automaticly
// "DClass"  - Will remove the grid, and make the grid before stretch out into double grid.
// "Chinese" - Will add a switcher for Japanese and Chinese class users
// ""        - Will set the grid as a blankclass grid automaticly

const element_primary = ["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"] // ["[Time]", "[Monday]", "[Tuesday]", "[Thursday]", "[Friday]"]
const classes_primary = ["Homeroom", "", "", "", "", "", "", "", "", "", "",
                         "Homeroom", "", "", "", "", "", "", "", "", "", "",
                         "Homeroom", "", "", "", "", "", "", "", "", "", "",
                         "Homeroom", "", "", "", "", "", "", "", "", "", "",
                         "Homeroom", "", "", "", "", "", "", "", "", "", "",]

// Second Class Names (Links will be filled in on primary names, just match your primary names with secondary.)
const element_secondary = ["Element 1", "Element 2", "Element 3", "Element 4", "Element 5", "Element 6"] // ["[Time]", "[Monday]", "[Tuesday]", "[Thursday]", "[Friday]"]
const classes_secondary = ["Secondary", "", "", "", "", "", "", "", "", "", "",
                           "Secondary", "", "", "", "", "", "", "", "", "", "",
                           "Secondary", "", "", "", "", "", "", "", "", "", "",
                           "Secondary", "", "", "", "", "", "", "", "", "", "",
                           "Secondary", "", "", "", "", "", "", "", "", "", "",]


// Subject's Google Meet and Google Classroom links.
// "[Subject]": {
//     "videocall": "[Video Call Link]",
//     "classroom": "[Classroom Link]"    
// }, <- Do not add the ',' if it's the last element.

const subj = {
    "Homeroom"  : {
        "videocall": "https://www.example.com/",
        "classroom": "https://www.example.com/"
    },
    "Tutor": {
        "videocall": "https://www.example.com/",
        "classroom": "https://www.example.com/"
    }
}

// Bookmarks
//
// "[! DO NOT EDIT !]": {
//     "rowname": "[Row Name]",
//     "rowname_secondary": "[Secondary Row Name]",
//     "[! DO NOT EDIT !]" {
//         "name": "[Bookmark Name]",
//         "name_secondary": "[Secondary Bookmark Name]",
//         "url": "[Bookmark URL]"
//     },
//     "[! DO NOT EDIT !]" {
//         "name": "[Bookmark Name]",
//         "name_secondary": "[Secondary Bookmark Name]",
//         "url": "[Bookmark URL]"
//     }
// }
//
// Fixed amount of bookmarks (4 links, 2 changeable name types)
//    Future update(s) might feature more customizable types

var bookmark_google_title_primary = "Search with Google"
var bookmark_google_title_secondary = "Example Search with Google"

var bookmark_google_search_primary = "Search"
var bookmark_google_search_secondary = "Example Search"

var bookmark_go_name_primary = "Go"
var bookmark_go_name_secondary = "Example Go"
var bookmarks = {
    "row0": {
        "rowname": "Example Row",
        "rowname_secondary": "Example Secondary",
        "content0": {
            "name": "Example Bookmark",
            "name_secondary": "Example Secondary",
            "url": "https://www.example.com/"
        },
        "content1": {
            "name": "Example Bookmark",
            "name_secondary": "Example Secondary",
            "url": "https://www.example.com/"
        },
        "content2": {
            "name": "Example Bookmark",
            "name_secondary": "Example Secondary",
            "url": "https://www.example.com/"
        },
        "content3": {
            "name": "Example Bookmark",
            "name_secondary": "Example Secondary",
            "url": "https://www.example.com/"
        }
    },
    "row1": {
        "rowname": "Example Row",
        "rowname_secondary": "Example Secondary",
        "content0": {
            "name": "Example Bookmark",
            "name_secondary": "Example Secondary",
            "url": "https://www.example.com/"
        },
        "content1": {
            "name": "Example Bookmark",
            "name_secondary": "Example Secondary",
            "url": "https://www.example.com/"
        },
        "content2": {
            "name": "Example Bookmark",
            "name_secondary": "Example Secondary",
            "url": "https://www.example.com/"
        },
        "content3": {
            "name": "Example Bookmark",
            "name_secondary": "Example Secondary",
            "url": "https://www.example.com/"
        }
    }
}