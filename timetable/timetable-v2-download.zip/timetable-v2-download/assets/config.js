// General variables
var versionnumber = "2.0.0"
var copyrightyear = "2022"

// If you want a switch for Japanese and Chinese class
var japanesechinese = false

// Time to be displayed in Timetable
const time = ["", "", "", "", "", "", "", "", "", "", ""]

// Class to be displayed in Timetable, each line represents each day.
// Automatic operations (All of the below is case-sensitive):
// "Lunch"   - Will set the grid as a lunch grid automaticly
// "DClass"  - Will remove the grid, and make the grid before stretch out into double grid.
// "Chinese" - Will add a switcher for Japanese and Chinese class users
// ""        - Will set the grid as a blankclass grid automaticly

const classes = ["", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",]

// Subject's Google Meet and Google Classroom links.
// "[Subject]": {
//     "videocall": "[Video Call Link]",
//     "classroom": "[Classroom Link]"    
// }, <- Do not add the ',' if it's the last element.

const subj = {
    "Homeroom": {
        "videocall": "https://www.example.com/",
        "classroom": "https://www.example.com/"
    },
    "[Subject]": {
        "videocall": "https://www.example.com/",
        "classroom": "https://www.example.com/"
    }
}

// Bookmarks
//
// "[! DO NOT EDIT !]": {
//     "name": "[Bookmark Name]"
//     "link": "[Bookmark Link]" 
// }
//
// Fixed amount of bookmarks (4 links, 2 unchangeable types)
//  -- Future update(s) might feature customizable types --

const bookmarks = {
    // QuickLinks
    "bookmark0": {
        "name": "Google Classroom",
        "url": "https://classroom.google.com/u/1/h"
    },
    "bookmark1": {
        "name": "Google Classroom - To Do",
        "url": "https://classroom.google.com/u/1/a/not-turned-in/all"
    },
    "bookmark2": {
        "name": "Google Meet",
        "url": "https://meet.google.com/landing?authuser=1"
    },
    "bookmark3": {
        "name": "Google Drive",
        "url": "https://drive.google.com/drive/u/1/"
    },

    // After School Links
    "bookmark4": {
        "name": "YouTube",
        "url": "https://www.youtube.com/"
    },
    "bookmark5": {
        "name": "Facebook",
        "url": "https://www.facebook.com/"
    },
    "bookmark6": {
        "name": "Instagram",
        "url": "https://www.instagram.com/"
    },
    "bookmark7": {
        "name": "Twitter",
        "url": "https://twitter.com/"
    }
}