// General variables
var versionnumber = "2.1.0"
var copyrightyear = "2022"

// If you want a switch for Japanese and Chinese class
var japanesechinese = false

// Time to be displayed in Timetable
const time = ["", "", "", "", "", "", "", "", "", "", ""]

// Class to be displayed in Timetable, each line represents each day.
// Automatic operations (All of the below is case-sensitive):
// "Lunch"   - Will set the grid as a lunch grid automaticly
// "DClass"  - Will remove the grid, and make the grid before stretch out into double grid.
// "Chinese" - Will add a switcher for Japanese and Chinese class users
// ""        - Will set the grid as a blankclass grid automaticly

const classes = ["", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",]


// Subject's Google Meet and Google Classroom links.
// "[Subject]": {
//     "videocall": "[Video Call Link]",
//     "classroom": "[Classroom Link]"    
// }, <- Do not add the ',' if it's the last element.

const subj = {
    "Homeroom": {
        "videocall": "https://www.example.com/",
        "classroom": "https://www.example.com/"
    },
    "[Subject]": {
        "videocall": "https://www.example.com/",
        "classroom": "https://www.example.com/"
    }
}

// Bookmarks
//
// "[! DO NOT EDIT !]": {
//     "rowname": "Example Row",
//     "[! DO NOT EDIT !]": {
//         "name": "Example Bookmark",
//         "url": "https://www.example.com/"
//     },
//     "[! DO NOT EDIT !]": {
//         "name": "Example Bookmark",
//         "url": "https://www.example.com/"
//     }
// }
//
// Fixed amount of bookmarks (4 links, 2 changeable name types)
//    Future update(s) might feature more customizable types

var bookmarks = {
    "row0": {
        "rowname": "Example Row",
        "content0": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content1": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content2": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content3": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        }
    },
    "row1": {
        "rowname": "Example Row",
        "content0": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content1": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content2": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content3": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        }
    }
}