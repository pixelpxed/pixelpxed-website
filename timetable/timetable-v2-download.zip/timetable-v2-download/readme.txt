
████████╗██╗███╗░░░███╗███████╗████████╗░█████╗░██████╗░██╗░░░░░███████╗
╚══██╔══╝██║████╗░████║██╔════╝╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░██╔════╝
░░░██║░░░██║██╔████╔██║█████╗░░░░░██║░░░███████║██████╦╝██║░░░░░█████╗░░
░░░██║░░░██║██║╚██╔╝██║██╔══╝░░░░░██║░░░██╔══██║██╔══██╗██║░░░░░██╔══╝░░
░░░██║░░░██║██║░╚═╝░██║███████╗░░░██║░░░██║░░██║██████╦╝███████╗███████╗
░░░╚═╝░░░╚═╝╚═╝░░░░░╚═╝╚══════╝░░░╚═╝░░░╚═╝░░╚═╝╚═════╝░╚══════╝╚══════╝

To setup your Timetable, go to '/assets/config.js' file
To use your Timetable, open the 'index.html' file

-- DO NOT EDIT HERE, EDIT AT CONFIG.JS FILE --

--------------------------------------------------------------------------------

If you want a switch for Japanese and Chinese class (Default false)

var japanesechinese = [true/false]

Example:
var japanesechinese = false

--------------------------------------------------------------------------------

Time to be displayed in Timetable

const time = ["", "", "", "", "", "", "", "", "", "", ""]

Example:
const time = ["08:00 - 08:40", "08:40 - 09:20", "09:20 - 10:00", "10:20 - 11:00", "11:00 - 11:40", "12:00 - 12:40", "12:40 - 13:20", "13:40 - 14:20", "14:20 - 15:00", "15:20 - 16:00", "16:00 - 16:40"]

--------------------------------------------------------------------------------

Class to be displayed in Timetable, each line represents each day.
  Automatic operations (All of the below is case-sensitive):
    "Lunch"   - Will set the grid as a lunch grid automaticly
    "DClass"  - Will remove the grid, and make the grid before stretch out into double grid.
    "Chinese" - Will add a switcher for Japanese and Chinese class users
    ""        - Will set the grid as a blankclass grid automaticly

const classes = ["", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",]

Example: 
const classes = ["Social", "Core English", "Core Science", "DClass", "Lunch", "Core Maths", "Thai", "R+W", "Tutor", "DClass",
                "Thai", "P.E.", "History", "Lunch", "Add Maths", "Art", "Mech. Work", "Core English", "Tutor", "DClass",
                "Health", "Core Science", "Flim Making", "DClass", "Lunch", "R+W", "Add Maths", "Chinese", "DClass", "",
                "Core Maths", "Buddhism", "Guidance", "Thai", "Lunch", "Music", "", "", "", "", 
                "Career", "Core Maths", "R+W", "Lunch", "Social", "Core English", "Additional Science", "DClass", "", ""]

--------------------------------------------------------------------------------

Subject's Google Meet and Google Classroom links.

"[Subject]": {
    "videocall": "[Video Call Link]",
    "classroom": "[Classroom Link]"    
}, <- Do not add the ',' if it's the last element.

Example:
const subj = {
    "Homeroom": {
        "videocall": "https://www.example.com/",
        "classroom": "https://www.example.com/"
    },
    "Social": {
        "videocall": "https://www.example.com/",
        "classroom": "https://www.example.com/"
    }
}

--------------------------------------------------------------------------------

Bookmarks

"[! DO NOT EDIT !]": {
    "rowname": "Example Row",
    "[! DO NOT EDIT !]": {
        "name": "Example Bookmark",
        "url": "https://www.example.com/"
    },
    "[! DO NOT EDIT !]": {
        "name": "Example Bookmark",
        "url": "https://www.example.com/"
    }
}

Fixed amount of bookmarks (4 links, 2 changeable name types)
   Future update(s) might feature more customizable types

Example:
var bookmarks = {
    "row0": {
        "rowname": "Example Row",
        "content0": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content1": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content2": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content3": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        }
    },
    "row1": {
        "rowname": "Example Row",
        "content0": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content1": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content2": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        },
        "content3": {
            "name": "Example Bookmark",
            "url": "https://www.example.com/"
        }
    }
}

--------------------------------------------------------------------------------

Last updated: 1/2/2022 (Happy Chinese New Year!)
© 2022 PixelEdition. All rights reserved.